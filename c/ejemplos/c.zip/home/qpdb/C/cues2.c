# include <stdio.h>

char cada_rta[0], respuestas[188], c;
int i;
int main(void)
{
  for(i = 0; i <= 5; i = i + 1)
    {
    printf("%d. Elija 'a', 'b' o 'c' y luego presione Enter. \n", i);
    c = getchar();
    while(c != 'a' && c != 'b' && c != 'c')
      {
	printf("Debe elegir a, b, o c, pero ingreso %c.\nIntente de nuevo: \n", c);
	c = getchar();
      }
    printf("\nLa tecla es: %c\n", c);
    respuestas[i] = c;
    }

  printf("Las respuestas: %s\n\n", respuestas);
  printf("cada_rta: %c\n\n", c);

  return 0;
}
